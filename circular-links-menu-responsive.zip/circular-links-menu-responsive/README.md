# circular links menu (responsive)

A Pen created on CodePen.io. Original URL: [https://codepen.io/rachsmith/pen/AMVQLw](https://codepen.io/rachsmith/pen/AMVQLw).

I saw Andy Thelander make a sweet circular links menu so I made a circular links menu. It's not as cool but whatevs. All javascript cause I'm lazy for markup.

You can check out the original inspiration at http://thlndr.com